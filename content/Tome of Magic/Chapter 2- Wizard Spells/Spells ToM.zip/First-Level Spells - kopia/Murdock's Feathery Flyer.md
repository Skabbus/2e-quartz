---
title: Murdock's Feathery Flyer-- 1st Level Wizard Spell (Tome of Magic)
source: https://regalgoblins.com/2erules/TM/DD04168.htm
type:
  - Spell
level: 1
school:
  - Alteration
spellist: Wizard
---

**Murdock's Feathery Flyer**

**(Alteration)** **Range:** 0**Components:** V, S, M**Duration:** 1 round/level**Casting Time:** 1**Area of Effect:** The caster**Saving Throw:** NoneUpon casting this spell, a feathery membrane grows under the wizard's arms, extending along his sides all the way to his feet. The membrane appears to merge with the caster's skin and clothing.

If the caster spreads his arms and jumps from a height, he may glide through the air. For each foot of elevation, the wizard can glide five feet horizontally. Thus, a wizard jumping from a 10-foot wall could glide up to 50 feet. Gliding characters have a movement rate of 12 and Maneuverability Class E. A wizard attempting to carry more than his normal weight allowance plummets to the earth upon takeoff.

When the spell expires, the feathers instantly disappear. If the wizard is airborne, he immediately plummets toward the ground.

The material component is an eagle's feather.

[[Tome of Magic/Table of Contents|Table of Contents]]
