---
title: Far Reaching III-- 5th Level Wizard Spell (Tome of Magic)
source: https://regalgoblins.com/2erules/TM/DD04208.htm
type:
  - Spell
level: 5
school:
  - Alteration
spellist: Wizard
---

> [!spell|alt] 5 | Far Reaching III
> | Range | AoE |
> | :--- | :--- |
> | 0Component: V | Special |
> | **Casting Time** | **Duration** |
> | 5 | Special |
> | **Save** | **Damage** |
> | None | — |
> | **Components** | **Material** |
> | V | — |
> 
> This spell operates exactly like the 3rd-level *far reaching I* spell except that the range of any spell of levels 1-3 is increased by 150% and the range of any 4th- or 5th-level spell is increased by 50%.
> 
> | **School** | **Sphere** |
> | :--- | :--- |
> | Alteration | — |
