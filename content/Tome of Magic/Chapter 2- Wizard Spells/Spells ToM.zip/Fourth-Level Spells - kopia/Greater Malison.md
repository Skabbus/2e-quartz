---
title: Greater Malison-- 4th Level Wizard Spell (Tome of Magic)
source: https://regalgoblins.com/2erules/TM/DD04197.htm
type:
  - Spell
level: 4
school:
  - Enchantment/Charm
spellist: Wizard
---

> [!spell|enc] 4 | Greater Malison
> | Range | AoE |
> | :--- | :--- |
> | 60 feetComponent: V | 30-foot-radius sphere |
> | **Casting Time** | **Duration** |
> | 4 | 2 rounds/level |
> | **Save** | **Damage** |
> | None | — |
> | **Components** | **Material** |
> | — | — |
> 
> This spell operates exactly like the 3rd-level *minor malison* spell except that the wizard places a -2 penalty on all saving throws of all hostile creatures within the area of effect. Optionally, the wizard may create a -3 penalty to saving throws against spells from one school of magic. This penalty is not cumulative with a saving throw penalty which derived from the wizard being a specialist; the penalty is not increased to -4.
> 
> | **School** | **Sphere** |
> | :--- | :--- |
> | Enchantment/Charm | — |
