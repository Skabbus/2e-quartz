---
title: Turn Pebble to Boulder-- 4th Level Wizard Spell (Tome of Magic)
source: https://regalgoblins.com/2erules/TM/DD04205.htm
type:
  - Spell
level: 4
school:
  - Alteration
spellist: Wizard
---

> [!spell|alt] 4 | Turn Pebble to Boulder *Reversible*
> | Range | AoE |
> | :--- | :--- |
> | Touch | Special |
> | **Casting Time** | **Duration** |
> | 4 | Special |
> | **Save** | **Damage** |
> | None | — |
> | **Components** | **Material** |
> | S V M | Pebbles, which revert to normal size when the spell expires |
> 
> At the culmination of this spell, the caster hurls a pebble which grows and increases in speed, becoming a deadly boulder that inflicts 3d6+8 points of damage if it strikes the target. (The rules for boulders as missile weapons apply as described in the [DUNGEON MASTER Guide](..\DMG\DD00449.htm).) The caster's THAC0 is used to determine success, and the caster is considered to be proficient with the thrown pebble and receives no penalty for range. The maximum range of attack is equal to 50 feet plus 10 feet per level of the caster. Only the caster may throw the pebble.
> 
> The wizard can enchant one stone at 7th level and gains one stone per three levels of experience thereafter (two stones at 10th level, three at 13th level, etc.). Only one pebble may be thrown per round, and pebbles must be hurled in consecutive rounds. The spell has a duration in rounds equal to the number of pebbles enchanted. Each pebble requires a separate attack roll. Pebbles may be thrown at different targets within range.
> 
> The material components are pebbles, which revert to normal size when the spell expires.
> 
> The reverse of this spell, *turn boulder to pebble*, shrinks a boulder to the size of a pebble. It affects only naturally occurring rocks and can not be used to shrink a statue or a cut gemstone.
> 
> The number of rocks that may be affected is equal to the number of experience levels of the caster. Boulders must not exceed one cubic foot per level of the caster. Thus, a 10th-level wizard could shrink 10 rocks, each of which is equal to or less than 10 cubic feet in size. All rocks are affected in the same round the spell is cast. Though they need not be touched, the boulders must be within 50 feet of the caster. Boulders that have been shrunk remain so until dispelled.
> 
> | **School** | **Sphere** |
> | :--- | :--- |
> | Alteration | — |
