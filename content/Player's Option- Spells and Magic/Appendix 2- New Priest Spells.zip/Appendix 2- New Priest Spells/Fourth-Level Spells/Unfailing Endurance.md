---
title: "Unfailing Endurance-- 4th Level Priest Spell (Spells and Magic)"
source: https://regalgoblins.com/2erules/SM/DD03702.htm
type:
  - Spell
level: 4
school:
  - Necromancy
sphere: Necromantic
---

Unfailing Endurance



(Necromancy)

    
 ---  --- 
 Sphere: Necromantic   
 Range: Touch  Components: V, S 
 Duration: 1 day/level  Casting Time: 1 round 
 Area of Effect: 1 creature/level  Saving Throw: 

None 
 

Subtlety: +5  Knockdown: 

None 
 

Sensory: 

None  Critical: 

None 

This spell enhances the natural hardiness and stamina of the affected creatures by rendering them virtually immune to fatigue or exhaustion. 

During the casting of the spell, the caster must touch each creature to be affected. While under the spell’s influence, the subjects may force march with no penalty, engage in up to 12 hours of hard labor per day with no fatigue (or up to 16 hours with moderate fatigue), and gain a +4 bonus to Strength/Stamina or Constitution/Fitness checks. In addition, the subjects gain a +4 bonus to saving throws against spells or magical effects that cause *weakness, fatigue*, or *enfeeblement*. Finally, an affected creature’s fatigue rating (from *Player’s Option:* *[Combat & Tactics](..\CT\DD02440.htm)*) is doubled, and the subject gains a +4 bonus to his saving throws to recover from a fatigued or exhausted state.

[[Player's Option- Spells and Magic/Table of ContentsTable of Contents]]
