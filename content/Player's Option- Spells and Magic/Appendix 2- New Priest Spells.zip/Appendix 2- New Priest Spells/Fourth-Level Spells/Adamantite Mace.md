---
title: "Fourth-Level Spells-- Priest (Spells and Magic)"
source: https://regalgoblins.com/2erules/SM/DD03696.htm
type:
  - Spell
level: 4
school:
  - Alteration
---

Fourth-Level SpellsAdamantite Mace
(Alteration)

    
 ---  --- 
 Sphere: Elemental (Earth)   
 Range: Touch  Components: V, S, M 
 Duration: 1 rd./level  Casting Time: 7 
 Area of Effect: Caster’s weapon  Saving Throw: 

None 
 

Subtlety: +5  Knockdown: d12 
 

Sensory: 

Small visual  Critical: 



Medium (1 hit) 
   impact 

By means of this spell, the priest transmutes his own cudgel, mace, or staff into an enchanted weapon of adamantite, the most magical mineral known. The *adamantite mace* gains a +2 bonus to attack and damage rolls, but it can strike creatures normally hit only by +4 or better weapons. As an incarnation of elemental earth, the mace inflicts up to twice the damage (roll twice the required damage dice) against creatures of elemental air or magical avians such as griffons, perytons, pegasi, and winged baatezu or tanar’ri. The *adamantite mace* retains its special properties for one round per level of experience of the caster.

The material component is a special powder made from a diamond worth 100 gp, sprinkled over the weapon.

[[Player's Option- Spells and Magic/Table of ContentsTable of Contents]]
