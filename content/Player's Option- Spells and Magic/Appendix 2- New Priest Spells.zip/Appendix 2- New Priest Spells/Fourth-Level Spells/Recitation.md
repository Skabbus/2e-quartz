---
title: "DD03700"
source: https://regalgoblins.com/2erules/SM/DD03700.htm
type:
  - Spell
school:
  - Abjuration
  - Invocation/Evocation
sphere: Combat
---

vRecitation
(Abjuration, Invocation/Evocation)

    
 ---  --- 
 Sphere: Combat   
 Range: 0  Components: V, S, M 
 Duration: 1 rd./level  Casting Time: 7 
 Area of Effect: 60-ft. radius  Saving Throw: 

None 
 

Subtlety: +5  Knockdown: 

None 
 

Sensory: 

Moderate audio  Critical: 

None 



By reciting a sacred passage or declaration, the priest invokes his deity’s blessing upon himself and his allies, while causing confusion and weakness among his enemies. All creatures within the area of effect at the instant of the spell’s completion are affected. Allies of the priest gain a +2 bonus to attack rolls and saving throws, or a +3 bonus if they are of the same faith (not just alignment) as the caster. Enemies suffer a –2 penalty to attack rolls and saving throws. After the *recitation*, the priest is free to take further actions during the spell’s duration as he sees fit—he need not concentrate to maintain the spell. As a result, it is possible for the priest to cast a *prayer* spell, which increases the bonuses and penalties provided to +3 and –3 respectively. If another priest is using *chant* at the same time, then the bonuses and penalties given by it are also allowed to add to the total.

The material spell component is the priest’s holy symbol and a copy of whatever text or scroll he holds sacred. Neither are consumed by the spell.

[[Player's Option- Spells and Magic/Table of ContentsTable of Contents]]
