---
title: "Omniscient Eye-- 4th Level Priest Spell (Spells and Magic)"
source: https://regalgoblins.com/2erules/SM/DD03699.htm
type:
  - Spell
level: 4
school:
  - Divination
sphere: Divination
---

Omniscient Eye



(Divination)

    
 ---  --- 
 Sphere: Divination   
 Range: 0  Components: V, S, M 
 Duration: 1 turn + 1 rd./level  Casting Time: 7 
 Area of Effect: The caster  Saving Throw: 

None 
 

Subtlety: +5  Knockdown: 

None 
 

Sensory: 

None  Critical: 

None 



This divination enhances the caster’s vision by allowing him to see through any normal or magical darkness, fog, or mist to a range of 60 feet. In addition, the caster has a chance of piercing magical illusions, blending, and invisibility equal to 70% plus 1% per level of experience, less 2% per spell level. For example, a 7th-level priest has a 70% + 7% - 4%, or 73% chance, to spot a wizard concealing himself by using the 2nd-level spell *invisibility*.Unlike the 5th-level spell *true seeing*, the *omniscient eye* does not grant the caster the ability to perceive secret doors, traps, lost or misplaced objects, or creature alignments; it simply ensures that the caster can see the surroundings as they would appear without the interference of weather, lighting, or illusionary magic. Thus, the *omniscient eye* can be deceived by careful camouflage, concealment, or other purely physical precautions. Other phenomena that may bypass this spell’s power include psionic invisibility, true transparency, or extradimensional objects or creatures.

The material component of this spell is a special ointment for the eyes that is composed of rare powders and herbs. The ointment costs at least 100 gold pieces for a single application.

[[Player's Option- Spells and Magic/Table of ContentsTable of Contents]]
