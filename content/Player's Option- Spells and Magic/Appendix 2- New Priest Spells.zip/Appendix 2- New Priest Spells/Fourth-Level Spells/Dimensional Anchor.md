---
title: "Dimensional Anchor-- 4th Level Priest Spell (Spells and Magic)"
source: https://regalgoblins.com/2erules/SM/DD03697.htm
type:
  - Spell
level: 4
school:
  - Alteration
sphere: Guardian
---

Dimensional Anchor



(Alteration)

    
 ---  --- 
 Sphere: Guardian   
 Range: 10 yds./level  Components: V, S 
 Duration: 1 turn + 1 rd./level  Casting Time: 1 
 Area of Effect: 1 creature  Saving Throw: 

None 
 

Subtlety: +2  Knockdown: 

None 
 

Sensory: 

Moderate visual  Critical: 

None 



When a priest casts this spell, a green ray springs from his outstretched hand and unerringly strikes a creature within line of sight and the range of the spell, covering the subject with a shimmering emerald field that completely blocks bodily extradimensional travel. Forms of movement barred by the *dimensional anchor* include *blinking, dimension door, etherealness, gate, phasing, plane shift, maze, shadow walk, teleportation,* and similar spell-like or psionic abilities. The field persists for one turn plus one round per caster level and has no effect other than blocking extradimensional travel. The *dimensional anchor* does not interfere with the movement of creatures in astral form, nor does it block extradimensional perception or attack forms such as a basilisk’s gaze.

[[Player's Option- Spells and Magic/Table of ContentsTable of Contents]]
