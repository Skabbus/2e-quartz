---
title: "Windborne-- 4th Level Priest Spell (Spells and Magic)"
source: https://regalgoblins.com/2erules/SM/DD03703.htm
type:
  - Spell
level: 4
school:
  - Conjuration/Summoning
---

Windborne



(Conjuration/Summoning)

    
 ---  --- 
 Sphere: Elemental (Air)   
 Range: 0  Components: V, S, M 
 Duration: Special  Casting Time: 7 
 Area of Effect: The caster  Saving Throw: 

None 
 

Subtlety: +5  Knockdown: 

None 
 

Sensory: 

Moderate visual  Critical: 

None 



This spell provides a priest of elemental air with the ability to conjure a powerful column of wind that can bear his weight, permitting him to fly or glide for long distances. If used from a high place such as a mountainside or tower, the caster can glide a maximum horizontal distance of 20 feet per foot of initial altitude—for example, if the priest used this spell and launched himself from a hilltop 800 feet high, he could glide a maximum distance of 16,000 feet, or about 3 miles.

If *windborne* is cast by a priest on level ground, the initial gust carries him aloft to a maximum altitude of 10 feet per caster level. From that point, he may then glide 10 feet per foot of initial altitude. For example, a 7th-level priest would ascend to an altitude of 70 feet and thus be able to glide for a total horizontal distance of 700 feet. He can choose to glide for a much shorter distance, but never less than his initial altitude.

While gliding, the priest moves at a rate of 15 (or about 450 feet) with a maneuverability class of D. Each round, he drops between 20 and 40 feet. He can choose to descend at a much more rapid pace, dropping up to 200 feet per round without risk of a damaging impact upon landing. The caster doesn’t gain a mastery of aerial combat with this spell and suffers a –2 penalty to his attack rolls and Armor Class if he becomes involved in combat while gliding.

The material component for this spell is the feather from a giant eagle .[[Player's Option- Spells and Magic/Table of ContentsTable of Contents]]
