---
title: "Second-Level Spells-- Priest (Spells and Magic)"
source: https://regalgoblins.com/2erules/SM/DD03676.htm
type:
  - Spell
level: 2
school:
  - Divination
sphere: Astral
---

Astral Awareness
(Divination)

 Sphere: Astral   
 Range: 0  Components: V, S 
 Duration: 1 hr./level  Casting Time: 5 
 Area of Effect: The caster  Saving Throw: None 
 Subtlety: +3  Knockdown: None 
 Sensory: None  Critical: None 



This divination attunes the caster’s perceptions to the silver void of the Astral Plane or the misty grayness of the Ethereal Plane. While the spell is in effect, the caster automatically notes the approach of all kinds of astral or ethereal phenomena, including shifting conduits, the psychic wind, ether cyclones, demiplanes and debris, color pools, and curtains of vaporous color. The character has a 90% chance to detect a color pool from its invisible side and a 5% chance per level to determine which plane a curtain or pool leads to simply by studying its color.

In addition to his awareness of physical phenomena, the caster gains a +2 bonus to surprise checks against astral or ethereal monsters. He also has a 5% chance per level to detect the threat of creatures whose gaze extends into the Ethereal (basilisks, for instance) before he enters the range of the monster’s gaze weapon.

[[Player's Option- Spells and Magic/Table of Contents|Table of Contents]]
