---
title: "Chaos Ward-- 2nd Level Priest Spell (Spells and Magic)"
source: https://regalgoblins.com/2erules/SM/DD03677.htm
type:
  - Spell
level: 2
school:
  - Abjuration
sphere: Chaos
---

Chaos Ward

(Abjuration)

 Sphere: Chaos   
 Range: Touch  Components: V, S, M 
 Duration: 2 rds./level  Casting Time: 5 
 Area of Effect: Creature touched  Saving Throw: None 
 Subtlety: +4  Knockdown: None 
 Sensory: Small visual  Critical: None 

By using this spell, the priest can create a shimmering aura of whirling light that surrounds the chosen creature. This protective aura makes the spell recipient more difficult to hit in hand-to-hand combat by providing a –1 bonus to the subject’s Armor Class. Against missile attacks or ranged spells aimed directly at the recipient, the *chaos ward* is even more effective since it provides a –2 bonus to Armor Class and a +2 bonus to any saving throws required. In addition, there is a chance that missile attacks or directed spells may be deflected or reflected by the chaotic energy of the shield, as shown below:

 ---  --- 
 d%1  Effect 
 01–85  No unusual effect, subject gains normal benefits of chaos ward 
 86–95  Spell or attack automatically defeated 
 96–99  Spell or attack ricochets, affecting a random creature within 30 feet—normal 
   attack roll or saving throw needs to be rolled for the random creature to be 
   affected 
 100+  Spell or attack reflected back at originator, normal attack roll or saving throw 
   applies 

1 Add the caster’s level to the d% roll.

In order to qualify as a spell aimed directly at the recipient, a spell must affect only the subject in question; a spell such as *hold person* or *sleep* that happens to include the subject in its area of effect does not count as a directed spell and does not trigger the *chaos ward*. The material component is a playing card used by a rogue of chaotic alignment.

[[Player's Option- Spells and Magic/Table of Contents|Table of Contents]]
