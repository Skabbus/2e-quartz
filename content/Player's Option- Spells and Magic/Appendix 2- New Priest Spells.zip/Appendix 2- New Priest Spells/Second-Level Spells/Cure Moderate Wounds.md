---
title: "Cure Moderate Wounds-- 2nd Level Priest Spell (Spells and Magic)"
source: https://regalgoblins.com/2erules/SM/DD03678.htm
type:
  - Spell
level: 2
school:
  - Necromancy
sphere: Healing
---

Cure Moderate Wounds



(Necromancy) Reversible

    
 ---  --- 
 Sphere: Healing   
 Range: Touch  Components: V, S 
 Duration: Instantaneous  Casting Time: 5 
 Area of Effect: Creature touched  Saving Throw: 

None 
 

Subtlety: +3  Knockdown: d8 
 

Sensory: 

Moderate visual  Critical: 



Medium (1 hit) 
 wounding when reversed   

Somewhat less common than the well-known *cure light wounds* and *cure serious wounds*, this healing spell was created by a priest who found that his heroic companions required his skill at doctoring more than his advice and wisdom. By laying his hand on the subject’s body, the priest can heal 1d10+1 points of damage. Noncorporeal, nonliving, or extraplanar creatures cannot be healed by this spell. The reverse of this spell, *cause moderate wounds*, requires the priest to successfully touch the victim and inflicts 1d10+1 points of damage. (The knockdown and critical strike entries above are for spell’s reverse.)[[Player's Option- Spells and Magic/Table of ContentsTable of Contents]]
