---
title: "Iron Vigil-- 2nd Level Priest Spell (Spells and Magic)"
source: https://regalgoblins.com/2erules/SM/DD03680.htm
type:
  - Spell
level: 2
school:
  - Alteration
sphere: Guardian
---

Iron Vigil



(Alteration)

    
 ---  --- 
 Sphere: Guardian   
 Range: 0  Components: V, S 
 Duration: 1 week + 1 day/level  Casting Time: 1 turn 
 Area of Effect: The caster  Saving Throw: 

None 
 

Subtlety: +5  Knockdown: 

None 
 

Sensory: 

None  Critical: 

None 



This spell allows the priest to ignore hunger, thirst, and extremes of climate for an extended period of time. While the spell is in effect, the priest requires no food or drink. He is effectively immune to exposure, dehydration, and heat or cold injury, since no naturally occurring climatic condition will cause him harm. (Lightning, floods, tornadoes, earthquakes, and other such hazardous phenomena can still cause physical injury, of course.)During the *iron vigil*, the priest is able to ignore the need to sleep by choosing to meditate instead. While meditating, the priest can keep watch on his surroundings, but he suffers a +1 penalty to any surprise checks. If the character wishes to memorize spells, he must sleep normally.

At the vigil’s end, the priest must eat and drink; if no food or water is available, the character must make a Constitution check once every four hours at a cumulative –1 penalty or fall into a coma and perish within 1d3 days if he receives no aid. He also requires at least four hours of rest for each day that he did not eat, drink, or sleep during his vigil.

[[Player's Option- Spells and Magic/Table of ContentsTable of Contents]]
