---
title: "Restore Strength-- 2nd Level Priest Spell (Spells and Magic)"
source: https://regalgoblins.com/2erules/SM/DD03682.htm
type:
  - Spell
level: 2
school:
  - Necromancy
sphere: Necromantic
---

Restore Strength



(Necromancy)

    
 ---  --- 
 Sphere: Necromantic   
 Range: Touch  Components: V, S 
 Duration: Instantaneous  Casting Time: 5 
 Area of Effect: Creature touched  Saving Throw: 

None 
 

Subtlety: +3  Knockdown: 

None 
 

Sensory: 

Moderate visual  Critical: 

None 



This spell removes unnatural weakness, debilitation, or exhaustion from the creature touched and restores him to his normal strength and stamina. It is useful in countering the effects of *chill touch, ray of enfeeblement, ray of fatigue,* the touch of a shadow or roper, and any similar spell or effect. Only temporary ability score losses may be alleviated by this spell; if a character suffers an incapacitating, physical injury, *restore strength* cannot help him. Also, loss of strength or stamina from purely natural causes such as exposure, disease, or exertion is not repaired by *restore strength*. The duration is permanent in that the subject remains at his maximum strength and endurance only until he is drained (or exerts himself) again.

[[Player's Option- Spells and Magic/Table of ContentsTable of Contents]]
