---
title: "Resist Acid and Corrosion-- 2nd Level Priest Spell (Spells and Magic)"
source: https://regalgoblins.com/2erules/SM/DD03681.htm
type:
  - Spell
level: 2
school:
  - Abjuration
sphere: Protection
---

Resist Acid and Corrosion



(Abjuration)

    
 ---  --- 
 Sphere: Protection   
 Range: Touch  Components: V, S 
 Duration: 1 rd./level  Casting Time: 5 
 Area of Effect: Creature touched  Saving Throw: 

None 
 

Subtlety: +3  Knockdown: 

None 
 

Sensory: 

None  Critical: 

None 



This spell provides a subject with a better resistance to acid, corrosives, and caustic substances of all kinds. Mild corrosives cannot harm the subject at all, although they can still damage his gear. More intense acids and corrosives (black dragon breath, *Melf’s acid arrow*, and the natural attacks of various puddings, oozes, slimes, and jellies) inflict only half the normal damage on the protected character. If the attack requires a saving throw, the subject gains a +3 bonus, sustaining half damage with a failed save or one-quarter damage with a successful saving throw.

[[Player's Option- Spells and Magic/Table of ContentsTable of Contents]]
