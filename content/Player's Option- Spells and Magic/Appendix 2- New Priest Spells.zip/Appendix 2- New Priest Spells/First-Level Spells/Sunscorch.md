---
title: "Sunscorch-- 1st Level Priest Spell (Spells and Magic)"
source: https://regalgoblins.com/2erules/SM/DD03674.htm
type:
  - Spell
level: 1
school:
  - Invocation/Evocation
sphere: Sun
---

Sunscorch

(Invocation/Evocation)

 Sphere: Sun   
 Range: 40 yds.  Components: V, S 
 Duration: Instantaneous  Casting Time: 4 
 Area of Effect: 1 creature  Saving Throw: Neg. 
 Subtlety: +3  Knockdown: d6 
 Sensory: Moderate visual,  Critical: Medium (1 moderate tactile  hit) fire 

This spell creates a brilliant ray of scorching heat that slants down from the sky to strike one target of the caster’s choice. The victim is entitled to a saving throw vs. spell to avoid the ray—a successful save indicates that it missed altogether. Any creature struck by the ray sustains 1d6 points of damage, plus 1 point per caster level. Undead creatures and monsters vulnerable to bright light sustain 1d6 points of damage, plus 2 points per caster level. In addition to sustaining damage, living victims are also blinded for 1d4 rounds by the spell.

The sun must be in the sky when *sunscorch* is cast, or the spell fails entirely. It cannot be cast underground, indoors, or in hours of darkness, although routine overcasts do not hinder the *sunscorch*.[[Player's Option- Spells and Magic/Table of Contents|Table of Contents]]
