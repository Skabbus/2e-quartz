---
title: "Strength of Stone-- 1st Level Priest Spell (Spells and Magic)"
source: https://regalgoblins.com/2erules/SM/DD03673.htm
type:
  - Spell
level: 1
school:
  - Invocation/Evocation
sphere: Elemental Earth
---

Strength of Stone

(Invocation/Evocation)

 Sphere: Elemental Earth   
 Range: Touch  Components: V, S, M 
 Duration: 3 rds.+ 1 rd./level  Casting Time: 4 
 Area of Effect: 1 creature  Saving Throw: None 
 Subtlety: +4  Knockdown: None 
 Sensory: None  Critical: None 

This spell grants supernatural strength to the recipient by raising his 

Strength score by 1d4 points or to a minimum of 16, whichever is higher. Each 10% of exceptional Strength counts as 1 point, so a character with a Strength of 17 could be raised as high as an 18/30, but no higher. Both the priest and the recipient must be in contact with solid stone or earth when the spell is cast—standing on the ground will do nicely, but *flying* or *swimming* will not. The spell lasts for 3 rounds plus 1 round per caster level or until the subject loses contact with the earth. Obviously, this can happen in a number of ways, including being picked up or grappled by a larger creature, being knocked through the air by an impact or explosion, or even being magically moved in some fashion.

The material components are a chip of granite and a hair from a giant.

[[Player's Option- Spells and Magic/Table of Contents|Table of Contents]]
