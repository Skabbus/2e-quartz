---
title: "Blessed Watchfulness-- 1st Level Priest Spell (Spells and Magic)"
source: https://regalgoblins.com/2erules/SM/DD03666.htm
type:
  - Spell
level: 1
school:
  - Alteration
sphere: Guardian
---

Blessed Watchfulness

(Alteration)

 Sphere: Guardian   
 Range: Touch  Components: V, S 
 Duration: 4 hrs. + 1 hr./level  Casting Time: 4 
 Area of Effect: Creature touched  Saving Throw: None 
 Subtlety: +3  Knockdown: None 
 Sensory: None  Critical: None 



By casting this spell, the priest confers exceptional powers of observation and alertness to one creature for the duration of the spell. While *blessed watchfulness* is in effect, the designated sentinel remains alert, awake and vigilant for the duration of the spell. In fact, it takes a roll of 1 to surprise someone under this effect. He resists *sleep* spells and similar magic as if he were 4 levels or Hit Dice higher than his actual level and gains a +2 bonus to saving throws against other spells or effects that could lower his guard or force him to abandon his watch, including *charm, beguiling, fear, emotion,* and similar mind-affecting spells. If the effect normally allows no saving throw, the watcher gains no special benefit.

[[Player's Option- Spells and Magic/Table of ContentsTable of Contents]]
