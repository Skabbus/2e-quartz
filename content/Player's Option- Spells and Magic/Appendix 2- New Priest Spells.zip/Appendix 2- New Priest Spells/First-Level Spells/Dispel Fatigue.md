---
title: "Dispel Fatigue-- 1st Level Priest Spell (Spells and Magic)"
source: https://regalgoblins.com/2erules/SM/DD03669.htm
type:
  - Spell
level: 1
school:
  - Necromancy
sphere: Necromantic
---

Dispel Fatigue

(Necromancy)

 Sphere: Necromantic   
 Range: 30 yds.  Components: V, S, M 
 Duration: Instantaneous  Casting Time: 4 
 Area of Effect: 1 creature  Saving Throw: None 
 Subtlety: +4  Knockdown: None 
 Sensory: None  Critical: None 

This spell removes physical fatigue or exhaustion from the subject by undoing the physiological effects of his exertions. 

The subject is instantly restored to his normal, fully rested level of endurance or vigor. This spell can be used to negate the penalties of forced marching, long swims, jogging, running, or sprinting, or even accumulated fatigue points from either the *Player’s Option:* *[Combat & Tactics](..\CT\DD02440.htm)

*rules or the magic fatigue rules in [[Player's Option- Spells and Magic/Chapter 6- Magic/Magic|Chapter 6]] . Once this spell has been cast, the subject may start to accumulate fatigue or fatigue-based penalties again, depending on how he continues to exert himself. The material component is a sprinkle of fresh, *blessed* springwater.

[[Player's Option- Spells and Magic/Table of Contents|Table of Contents]]
