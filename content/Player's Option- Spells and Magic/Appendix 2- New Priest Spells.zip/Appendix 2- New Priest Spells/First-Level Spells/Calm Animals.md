---
title: "Calm Animals-- 1st Level Priest Spell (Spells and Magic)"
source: https://regalgoblins.com/2erules/SM/DD03668.htm
type:
  - Spell
level: 1
school:
  - Enchantment/Charm
sphere: Animal
---

Calm Animals

(Enchantment/Charm)
 
 Sphere: Animal   
 Range: 60 yds.  Components: V, S 
 Duration: 1 turn + 1 rd./level  Casting Time: 4 
 Area of Effect: Special  Saving Throw: Special 
 Subtlety: +3  Knockdown: None 
 Sensory: Moderate audio  Critical: None 



This spell soothes and quiets normal animals, which renders them docile and harmless. Only creatures with Intelligence ratings of 1 to 4 (in other words, animal- or semi-intelligent creatures) can be affected by this spell. The caster can calm 2d4 Hit Dice of animals, plus 1 Hit Die per level, so a 4th-level priest could affect 2d4+4 Hit Dice of creatures. The caster can affect any animals he wishes to within the spell’s range, but all the subjects must be of the same species. The subject creatures are not allowed a saving throw unless they have magical powers, abilities, or are clearly not entirely natural; a priest could calm a normal bear, war dog, or wolf with little trouble, but it’s more difficult to affect a winter wolf, hell hound, or owlbear.

While under the influence of this spell, the affected creatures remain where they are and do not attack or flee, unless they are attacked or confronted by a significant hazard such as a fire or a hungry predator. Once roused, the spell’s magic is broken and the animals are free to act in whatever fashion they normally would. Note that creatures affected by this spell are not helpless and defend themselves normally if attacked.

[[Player's Option- Spells and Magic/Table of ContentsTable of Contents]]
