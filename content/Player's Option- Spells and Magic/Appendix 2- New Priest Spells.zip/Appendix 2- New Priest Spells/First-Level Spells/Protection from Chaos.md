---
title: "Protection from Chaos-- 1st Level Priest Spell (Spells and Magic)"
source: https://regalgoblins.com/2erules/SM/DD03672.htm
type:
  - Spell
level: 1
school:
  - Abjuration
sphere: Law
---

Protection from Chaos

(Abjuration)

 Sphere: Law   
 Range: Touch  Components: V, S, M 
 Duration: 3 rds./level  Casting Time: 4 
 Area of Effect: 1 creature  Saving Throw: None 
 Subtlety: +4  Knockdown: None 
 Sensory: Small visual  Critical: None 



Resembling the spell *protection from evil*, this abjuration wards the creature touched from the attacks of minions of chaos. Chaotic creatures suffer a –2 penalty to attack rolls against the spell recipient, and the subject gains a +2 bonus to saving throws against spells or other attacks employed by chaotic creatures. Attempts to possess, dominate, or exercise other forms of mental control against the recipient are automatically blocked by this spell.

*Protection from chaos* also wards the recipient against contact with extraplanar creatures of chaotic origin, including tanar’ri, slaad, and eladrin. Unlike *protection from evil*, this spell does not necessarily guard against summoned or conjured creatures unless the creatures in question are chaotic in alignment. However, *protection from chaos* does protect the recipient from creatures influenced by confusion and chaos spells and effects. The natural or bodily attacks of such creatures automatically fail, as long as the recipient does not use the spell’s power to trap, pin, or drive back the chaotic creatures in question. The spell ends if the recipient makes a melee attack against creatures that are prevented from attacking him by this spell.

The material component is a small ring of gold or lead tempered by a chaotic smith. Note that this spell is not reversible.

[[Player's Option- Spells and Magic/Table of Contents|Table of Contents]]
