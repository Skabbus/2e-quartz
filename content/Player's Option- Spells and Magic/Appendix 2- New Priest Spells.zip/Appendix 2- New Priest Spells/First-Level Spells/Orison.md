---
title: "Orison-- 1st Level Priest Spell (Spells and Magic)"
source: https://regalgoblins.com/2erules/SM/DD03671.htm
type:
  - Spell
level: 1
school:
  - Various schools
sphere: All
---

Orison

(Various schools)

 Sphere: All   
 Range: 10 yds.  Components: V, S 
 Duration: Special  Casting Time: 4 
 Area of Effect: Varies  Saving Throw: None 
Subtlety: +3  Knockdown: None 
 Sensory: Small visual/audio  Critical: None 



The most humble of priestly spells is the orison, a brief prayer or invocation of a minor nature. Typically, priests learn a number of *orisons* as acolytes or students in order to hone their spellcasting skills and emphasize concepts, ideals, or phrases of particular importance to the faith. Because an *orisons* is not even on par with other 1st-level magic, a priest memorizes a number of individual *orisons* equal to three +1 per level (up to a maximum of nine) when he devotes a 1st-level spell slot to *orison*. In other words, a 1st-level priest can memorize four *orisons* for one 1st-level spell slot, a 2nd-level priest can memorize five, and so on.

Unlike *cantrip*, an *orison* must have a specific effect, although the priest need not decide which incantation he will use until he actually casts the spell. Regardless of the prayer chosen, the *orison’s* duration is never more than one round per level. Known *orisons* include the following:

Alleviate: A single creature suffering from nausea or pain is relieved of its discomfort. Magically induced nausea or pain is only alleviated if the victim passes a saving throw vs. spell with a –2 penalty.

Calm: A single creature that has been startled or frightened is soothed. Victims suffering from magical fear may attempt a save vs. spell with a –2 penalty to calm themselves.

Clarity: For the duration of the orison, the priest’s speech is clear and free of impediment—useful for readings from sacred texts and other such rites. Magical conditions such as *confuse languages* cannot be overcome by this *orison*.Courage: The priest gains a +1 bonus to his next attack roll, as long as the attack is made within the spell’s duration.

Guidance: The priest gains a +1 bonus to a Wisdom or Intelligence check to determine the right course of action in a moral dilemma or puzzle.

Healing: By his touch, the priest may heal a creature of 1 point of damage.

Magic sense: If there is a persistent spell effect or magical item within 10 yards, the priest feels a recognizable tingle or sensation of some kind. He has no way to determine what item or spell may have caused the reaction.

Memory: Any item the priest commits to memory during the spell duration is more completely and permanently learned; he gains a +2 bonus to any checks to recall the exact appearance, wording, or meaning of an item, text, or message.

Resistance to magic: The caster gains a +1 bonus to his next saving throw against magic of any type, as long as it occurs during the *orison’s* duration.

Resistance to poison: The priest gains a +1 bonus to his next saving throw vs. poison, as long as it occurs during the *orison’s* duration.

Other orisons of similar power or scope may be permitted by the DM. Generally, an *orison* should not affect more than one creature or die roll at a time, and an *orison* that can actually cause immediate harm to a creature should inflict no more than 1 or 2 points of damage. An offensive *orison* would be quite rare and most probably associated with an evil or chaotic priesthood.

[[Player's Option- Spells and Magic/Table of Contents|Table of Contents]]
