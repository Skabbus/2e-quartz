---
title: "Wind Column-- 1st Level Priest Spell (Spells and Magic)"
source: https://regalgoblins.com/2erules/SM/DD03675.htm
type:
  - Spell
level: 1
school:
  - Invocation/Evocation
sphere: Elemental Air
---

Wind Column

(Invocation/Evocation)

 Sphere: Elemental Air   
 Range: 0  Components: S 
 Duration: 2 rds./level  Casting Time: 1 
 Area of Effect: The caster  Saving Throw: None 
 Subtlety: +1  Knockdown: None 
 Sensory: Moderate visual  Critical: None 



A priest with access to this spell need not fear most routine falls, since the casting of the *wind column* creates a pillar of strong winds to slow his descent. The spell is most effective in areas or regions where a strong breeze is available, such as the heights of a mountain or the mast of a ship at sea. In areas of dead, calm air, it is much more difficult to muster the windpower necessary to arrest the caster’s fall. The caster’s rate of descent (and risk of damage) varies with the strength of the prevailing winds, as shown below.

If the wind is very strong, the caster can even choose to gain altitude instead of falling, although he can rise no higher than 5 feet per level above his original height before the *wind column* loses cohesiveness and he starts to fall again. However, a priest could use this to leap out a castle window and allow the winds to bear him to the roof of the tower, if the conditions are right.

      
 ---  ---  --- 
 Wind  Falling  Damage 
 Strength  Rate  Sustained 
 Very strong  ±2 ft./sec. (120 ft./rd.)  None 
 Strong  4 ft./sec. (240 ft./rd.)  None 
 Moderate  8 ft./sec. (480 ft./rd.)  1 per 10 ft.1 
 Light  16 ft./sec. (960 ft./rd.)  1d2 per 10 ft.2 
 None  32 ft./sec. (2000 ft./rd.)  1d3 per 10 ft.3 

1 Maximum of 8 points2 Maximum of 10d23 Maximum of 12d3If you prefer to use the combat round scale from *Player’s Option:* *[Combat & Tactics](..\CT\DD02384.htm)*, rounds are approximately one-tenth as long, and movement per round is reduced accordingly. For example, in moderate winds, the caster will fall about 48 feet per round in the [Combat & Tactics](..\CT\DD02382.htm) scale.

[[Player's Option- Spells and Magic/Table of Contents|Table of Contents]]
