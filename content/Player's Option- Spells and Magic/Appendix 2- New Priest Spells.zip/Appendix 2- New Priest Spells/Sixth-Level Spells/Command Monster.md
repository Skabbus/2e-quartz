---
title: "Sixth-Level Spells-- Priest (Spells and Magic)"
source: https://regalgoblins.com/2erules/SM/DD03710.htm
type:
  - Spell
level: 6
school:
  - Enchantment/Charm
sphere: Charm
---

Sixth-Level SpellsCommand Monster
(Enchantment/Charm)

    
 ---  --- 
 Sphere: Charm   
 Range: 60 yds.  Components: V 
 Duration: 1 rd./2 levels  Casting Time: 1 
 Area of Effect: 1 creature  Saving Throw: 

Special 
 

Subtlety: +1  Knockdown: 

None 
 

Sensory: 

Small audio  Critical: 

None 



This spell allows the priest to issue a *command* to any one creature within the spell’s range. The magic of the spell translates the priest’s order into a language or form the subject creature can understand. The creature must have an Intelligence of at least 1 in order to be affected by this spell; nonintelligent creatures (those with a score of 0) cannot comprehend any order, no matter how the priest phrases it. Other creatures gain a saving throw vs. spell to resist *command monster*, but only if they have an Intelligence of Exceptional (15) or better, or the creature’s levels or Hit Dice are equal to or greater than the caster’s.

Just like the 1st-level spell *command*, this spell coerces the subject into obeying the priest’s one-word order to the best of its ability. The order must be absolutely clear and unequivocal; the subject will continue to obey for one round per two caster levels—six rounds at 12th level, seven at 14th, and so on. If this action places the subject in mortal peril, he may attempt a saving throw (whether he was originally entitled to one or not) in order to break free of the spell’s power. Therefore, ordering a character standing at the edge of a cliff to “jump” will create an opportunity for the subject to break free. A command to “die” or “sleep” renders the creature unconscious for the spell’s duration.

Undead creatures are immune to this spell.

[[Player's Option- Spells and Magic/Table of ContentsTable of Contents]]
