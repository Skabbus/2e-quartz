---
title: "Whirlwind-- 6th Level Priest Spell (Spells and Magic)"
source: https://regalgoblins.com/2erules/SM/DD03712.htm
type:
  - Spell
level: 6
school:
  - Invocation/Evocation
---

Whirlwind



(Invocation/Evocation)

    
 ---  --- 
 Sphere: Elemental (Air)   
 Range: 60 yds. + 10 yds./level  Components: V, S, M 
 Duration: 1 rd./level  Casting Time: 9 
 Area of Effect: Cone 10 ft.  Saving Throw: 

Special 
 wide at base and 30 ft. tall   
 

Subtlety: +6  Knockdown: d20 
 

Sensory: 

Huge visual/audio,  Critical: 



Large (1d3 
 large tactile  hits) crushing 

This spell creates a powerful cyclone of raging wind that moves as directed by the priest. The *whirlwind* can move by zigzagging along the ground or over water at a movement rate of 6. The *whirlwind* always moves after all other creatures have moved, and many creatures can avoid it simply by keeping their distance. If the cyclone exceeds the spell’s range, it moves in a random, uncontrolled fashion for 1d3 rounds—possibly endangering the caster or his allies—and then dissipates.

Any creature of size L (large) or smaller that comes in contact with the *whirlwind* must make a saving throw vs. breath weapon or suffer 2d8 damage. Size M (man-sized) or smaller creatures who fail their first saving throw must attempt a second one, or be picked up bodily by the *whirlwind* and held suspended in its powerful winds, suffering 1d8 points of damage each round with no save allowed. The caster may direct the cyclone to eject any carried creatures whenever he wishes, depositing the hapless souls wherever the *whirlwind* happens to be when they are released.

Maintaining the *whirlwind* requires the caster’s full attention, and he cannot cast other spells or make any attacks while directing the spell’s course. If his concentration fails for some reason, he cannot simply cancel the spell. Instead, the spell becomes uncontrolled as described above and dissipates after 1d3 rounds.

In truly desperate circumstances, priests of elemental air have been known to deliberately overrun their companions in order to carry them out of the path of some certain doom. Few care to repeat the experience. The material component for this spell is a handful of dust collected from a zephyr or snow from a williwaw.

[[Player's Option- Spells and Magic/Table of ContentsTable of Contents]]
