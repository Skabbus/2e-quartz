---
title: "Entropy Shield-- 6th Level Priest Spell (Spells and Magic)"
source: https://regalgoblins.com/2erules/SM/DD03711.htm
type:
  - Spell
level: 6
school:
  - Abjuration
sphere: Chaos
---

Entropy Shield



(Abjuration)

    
 ---  --- 
 Sphere: Chaos   
 Range: 0  Components: V, S, M 
 Duration: 1 rd./level  Casting Time: 9 
 Area of Effect: The caster  Saving Throw: 

None 
 

Subtlety: +5  Knockdown: 

None 
 

Sensory: 

Moderate visual/tactile  Critical: 

None 

This potent defense surrounds the caster in a chaotic maelstrom of energy and demimatter that blocks or deflects many attacks. 

The *entropy shield* extends about two feet in all directions from the caster’s body. The warping effect of the field causes any melee or hand-to-hand attack to miss 50% of the time—even if the roll allows an attack to continue, the priest still gains a –2 bonus to his Armor Class. Normal missiles or hurled weapons miss automatically as the *entropy shield* deflects them from the caster. Even magical missile attacks (*produce flame, magic missile*, or *Melf’s acid arrow*, for example), siege engines, and giant-thrown boulders may be deflected as if they were hand-to-hand attacks.

Against spells or effects that produce energy, gas, or other physical attack forms (*fireball, lightning bolt, cloudkill,* and other such spells) the *entropy shield* provides a 50% chance that the attack simply does not affect the protected priest. Even if the harmful energy or matter penetrates the shield, the caster gains a +2 bonus on his saving throw. This does not cause a spell to fizzle or fail; a priest standing in the middle of a *fireball* is simply not touched by the spell, which will inflict its normal damage on anyone else in the area of effect. Any spell or effect that does not create matter or energy to harm or hinder the victim can pass through the *entropy shield* normally, so mind-based attacks and magical effects such as *petrification, paralyzation, enfeeblement*, or *polymorph* (to name a few) can still affect the priest.

In addition to its defensive benefits, the *entropy shield* has the ability to repel normal or giant-sized animals and creatures of lawful alignment, such as extraplanar monsters from the lawful planes. Any such creature attempting to attack the shielded priest in hand-to-hand combat must roll a saving throw vs. spell at the end of the round. If the creature fails, it recoils from the priest and cannot attack him physically for the remainder of the spell’s duration (although it could decide to turn on one of the priest’s companions).

The material component for this spell is a gemstone worth at least 100 gold pieces that has been exposed to the chaotic energies of Limbo.

[[Player's Option- Spells and Magic/Table of ContentsTable of Contents]]
