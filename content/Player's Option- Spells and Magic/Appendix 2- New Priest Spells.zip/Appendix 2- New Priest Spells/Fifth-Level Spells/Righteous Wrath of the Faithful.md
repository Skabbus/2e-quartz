---
title: "Righteous Wrath of the Faithful-- 5th Level Priest Spell (Spells and Magic)"
source: https://regalgoblins.com/2erules/SM/DD03709.htm
type:
  - Spell
level: 5
school:
  - Enchantment/Charm
sphere: War
---

Righteous Wrath of the Faithful



(Enchantment/Charm)

    
 ---  --- 
 Sphere: War   
 Range: 0  Components: V, S, M 
 Duration: 1 rd./level  Casting Time: 8 
 Area of Effect: 30-ft. radius  Saving Throw: 

None 
 

Subtlety: +5  Knockdown: 

None 
 

Sensory: 

None  Critical: 

None 



When a priest casts this spell, he fires his allies and companions with a divine madness or fury that greatly enhances their combat ability. Allies who are fighting on the side of the priest are affected as if they had received an aid spell, gaining a +1 bonus to attack rolls and saving throws, plus 1d8 additional hit points for the duration of the spell.

Allies who share the same faith (not just alignment) of the caster are transported into the *righteous wrath*; they gain one additional melee attack each round and a +2 bonus to saving throws and attack and damage rolls. Creatures under the influence of the *righteous wrath* gain 1d8 additional hit points, which are the first points lost if the subject sustains any injury (see *aid*, on page 257 of the [PHB](..\PHB\DD02145.htm#f8e3802a) ). Characters in a state of divine frenzy are difficult to *charm* or *hold*. Against spells or effects that target the subject’s mind or emotions, the saving throw bonus increases to +3.

When the spell ends, all remaining additional hit points are lost. Characters who fought under the righteous wrath find themselves extremely fatigued and must rest for one full turn before exerting themselves again; if forced to fight in this state, they are treated as if they were *exhausted* under the [Combat & Tactics](..\CT\DD02440.htm)fatigue rules. The material component of this spell is the priest’s holy symbol.

[[Player's Option- Spells and Magic/Table of ContentsTable of Contents]]
