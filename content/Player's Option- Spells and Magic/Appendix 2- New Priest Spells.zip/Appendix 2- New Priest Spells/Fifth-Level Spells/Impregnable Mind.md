---
title: "Impregnable Mind-- 5th Level Priest Spell (Spells and Magic)"
source: https://regalgoblins.com/2erules/SM/DD03706.htm
type:
  - Spell
level: 5
school:
  - Enchantment/Charm
---

Impregnable Mind



(Enchantment/Charm)

    
 ---  --- 
 Sphere: Protection, Thought   
 Range: Touch  Components: V, S 
 Duration: 1 turn + 1 rd./level  Casting Time: 1 
 Area of Effect: Creature touched  Saving Throw: 

None 
 

Subtlety: +2  Knockdown: 

None 
 

Sensory: 

None  Critical: 

None 

This spell guards the spell recipient against magical or psionic attacks that affect the mind. 

This includes *beguiling, charm, domination, feeblemind, hold*, and similar effects, as well as most telepathic psionic powers and attacks. Against magical influences, *impregnable mind* grants a +4 bonus to saving throws; if the attack normally allows no saving throw, the spell recipient may attempt one at no modifier. Against telepathic psionics, the spell inflicts a –6 penalty to the attacking psionicist’s power checks, making it more likely that a psionic attack or telepathic contact will fail. *Impregnable mind* offers no protection against nontelepathic psionics, such as a telekinetic thrashing or other psionics that affect the body.

[[Player's Option- Spells and Magic/Table of ContentsTable of Contents]]
