---
title: "Wind Servant-- 3rd Level Priest Spell (Spells and Magic)"
source: https://regalgoblins.com/2erules/SM/DD03695.htm
type:
  - Spell
level: 3
school:
  - Conjuration/Summoning
---

Wind Servant



(Conjuration/Summoning)

    
 ---  --- 
 Sphere: Elemental (Air)   
 Range: 20 yds./level  Components: V, S 
 Duration: 1 rd./level  Casting Time: 6 
 Area of Effect: Special  Saving Throw: 

None 
 

Subtlety: +3  Knockdown: 

None 
 

Sensory: 

Moderate audio/tactile  Critical: 

None 



This spell allows the priest to exert fine control over air currents and winds, possibly extinguishing small fires or manipulating light objects as he sees fit within the spell’s range. Generally, the priest is limited to one discrete action per round since he must focus his wind servant tightly on any given task. The *wind servant* can affect objects or creatures weighing up to 1 pound per caster level, twice as much if the object is reasonably light or airy (a cloak, scroll, or haystack, for instance), or 10 times as much if the object is designed to be carried by the wind, such as a ship’s sail or a bird in flight.

If an object is within the spell’s weight limit, the caster may direct the *wind servant* to carry it along in gusts and air currents at a flying movement rate of 12 (E). If the object leaves the limits of the spell’s range, the *wind servant* fails, and the object drops or falls normally from that point. Flying creatures of size M or smaller can be forced to land or be driven away by use of the spell if they fall within the weight limit, or slowed by 50% if they exceed the weight limit. Employing the *wind servant* against an arrow or light missile adds a penalty of –4 to the attack roll.

In dusty, snowy, or sandy regions, the caster can instead use *wind servant* to create a vicious zephyr of stinging dust around an enemy. This zephyr inflicts damage equal to the opponent’s base AC less 2d6 points and creates a –2 penalty to the victim’s attack rolls. For example, an enemy in leather armor +1 (AC 7) would suffer 7 – 2d6 damage if attacked by means of this spell. Note that any use of the *wind servant* requires the priest’s undivided attention; he can take no other actions while directing the spell.

[[Player's Option- Spells and Magic/Table of ContentsTable of Contents]]
