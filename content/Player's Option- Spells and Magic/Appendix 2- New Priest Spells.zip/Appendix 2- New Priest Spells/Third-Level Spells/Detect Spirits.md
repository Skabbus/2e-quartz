---
title: "Detect Spirits-- 3rd Level Priest Spell (Spells and Magic)"
source: https://regalgoblins.com/2erules/SM/DD03686.htm
type:
  - Spell
level: 3
school:
  - Divination
sphere: Divination
---

Detect Spirits



(Divination)

    
 ---  --- 
 Sphere: Divination   
 Range: 0  Components: V, S, M 
 Duration: 1 turn + 1 turn/level  Casting Time: 6 
 Area of Effect: 10 x 60 ft. path  Saving Throw: 

None 
 

Subtlety: +4  Knockdown: 

None 
 

Sensory: 

Moderate visual  Critical: 

None 



This divination reveals the presence of disembodied or noncorporeal spirits of all types, including wraiths, ghosts, spectres, astrally-projecting creatures, characters or monsters employing *magic jar* or possession, and (of course) animal spirits and spirits of nature. Characters or monsters who are simply *invisible, phased*, or *ethereal* do not count as spirits, since they are physically present in the flesh despite their unusual status. The caster detects spirits in a path 10 feet wide and 60 feet long; any within the area of effect are revealed in their preferred form or appearance for all to see. Simply detecting a spirit doesn’t give the caster any special ability to communicate with or attack the entity.

The material component for this spell is a small pendant of copper wire worth at least 20 gp.

[[Player's Option- Spells and Magic/Table of ContentsTable of Contents]]
