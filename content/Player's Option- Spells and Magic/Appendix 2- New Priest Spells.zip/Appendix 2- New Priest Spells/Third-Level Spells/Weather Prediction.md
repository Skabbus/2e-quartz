---
title: "Weather Prediction-- 3rd Level Priest Spell (Spells and Magic)"
source: https://regalgoblins.com/2erules/SM/DD03694.htm
type:
  - Spell
level: 3
school:
  - Divination
sphere: Weather
---

Weather Prediction



(Divination)

    
 ---  --- 
 Sphere: Weather   
 Range: 0  Components: V, S 
 Duration: Instantaneous  Casting Time: 1 rd. 
 Area of Effect: The caster  Saving Throw: 

None 
 

Subtlety: +5  Knockdown: 

None 
 

Sensory: 

None  Critical: 

None 



By casting this spell, the priest can predict the weather conditions at his location for a period of time equal to one day per level. The caster becomes aware of the prevailing conditions, trends, and weather systems that may affect his present location. Temperature, wind speed and direction, cloud cover, and precipitation can all be predicted with 95% accuracy for the next day, less 10% for each day after that. In other words, the priest’s prediction is 95% accurate for the first day, 85% accurate for the second, 75% accurate for the third, and so on. In addition, magical or supernatural phenomena cannot be predicted.

Priests of powers concerned with weather may use this spell to determine the best time for certain ceremonies or observances. Other priests find *weather prediction* useful for planning journeys or selecting campsites.

[[Player's Option- Spells and Magic/Table of ContentsTable of Contents]]
