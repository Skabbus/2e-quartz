---
title: "Unfailing Premonition-- 3rd Level Priest Spell (Spells and Magic)"
source: https://regalgoblins.com/2erules/SM/DD03693.htm
type:
  - Spell
level: 3
school:
  - Divination
sphere: Time
---

Unfailing Premonition



(Divination)

    
 ---  --- 
 Sphere: Time   
 Range: 0  Components: V, S 
 Duration: 1 turn + 2 rds./level  Casting Time: 6 
 Area of Effect: The caster  Saving Throw: 

None 
 

Subtlety: +3  Knockdown: 

None 
 

Sensory: 

None  Critical: 

None 



By anticipating possible futures and outcomes of the caster’s actions, this spell provides the character with a temporary sixth sense or feel for danger. The spell operates on a subconscious level, and the caster receives strong intuitive impulses when he contemplates courses of action that may bring immediate physical injury or harm to him. For example, if the priest was about to open a trapped chest, the *unfailing premonition* would create a flash of insight or a gut feeling telling him that he shouldn’t do so. Similarly, opening a door that leads into the lair of a ferocious troll may also trigger the spell’s warning. Threatening a NPC who is likely to respond by drawing a weapon and attacking the PC would create a warning, but threatening a NPC who will get even with the priest in an hour or two will not trigger the *premonition.

*The *unfailing premonition* is also quite useful in combat, as long as the priest obeys his instincts and ducks, dodges, or withdraws when his subconscious tells him to. While the spell is in effect, the priest gains a +2 bonus to his Armor Class and saving throws, but in any given round there is a 25% chance that he will have to forego his intended action in order to obey the spell’s warning impulses.

The *premonition* only works on actions undertaken by the priest himself. If his companion is about to pull a mysterious lever that will drop a 10-ton block of stone on the priest, he receives no warning.

[[Player's Option- Spells and Magic/Table of ContentsTable of Contents]]
