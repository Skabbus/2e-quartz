---
title: "Seventh-Level Spells-- Priest (Spells and Magic)"
source: https://regalgoblins.com/2erules/SM/DD03713.htm
type:
  - Spell
level: 7
school:
  - Abjuration
---

Seventh-Level SpellsAntimineral Shell
(Abjuration)

    
 ---  --- 
 Sphere: Protection, Elemental (Earth)   
 Range: 0  Components: V, S, M 
 Duration: 1 turn/level  Casting Time: 1 round 
 Area of Effect: 10-ft. radius  Saving Throw: 

None 
 

Subtlety: +6  Knockdown: 

None 
 

Sensory: 

None  Critical: 

None 



When a priest casts this spell, he creates an invisible force field or barrier that blocks the entrance of animated or living mineral creatures. It is effective against elementals and creatures of elemental origin such as aerial servants, djinns, and mephits; golems and other constructs; creatures of living stone, such as galeb duhr or xorn; and objects, weapons, or armor animated by some outside force. It does not bar the passage of undead monsters, living creatures carrying inanimate material, or nonanimated minerals such as a giant-thrown boulder or a common rockslide. The *antimineral shell* moves with the caster, but if the caster tries to force it against a creature affected by this spell, the *antimineral shell* fails. The material component is a drop of some caustic solvent, such as acid from a black dragon.

[[Player's Option- Spells and Magic/Table of ContentsTable of Contents]]
