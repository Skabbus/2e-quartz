---
title: "Conjure Air or Water Elemental-- 7th Level Priest Spell (Spells and Magic)"
source: https://regalgoblins.com/2erules/SM/DD03714.htm
type:
  - Spell
level: 7
school:
  - Conjuration/Summoning
---

Conjure Air or Water Elemental



(Conjuration/Summoning) Reversible

    
 ---  --- 
 Sphere: Elemental (Air/Water)   
 Range: 80 yds.  Components: V, S 
 Duration: 1 turn/level  Casting Time: 6 rds. 
 Area of Effect: Special  Saving Throw: 

None 
 

Subtlety: +5  Knockdown: 

None 
 

Sensory: 

Moderate visual  Critical: 

None 



Priests of elemental air or elemental water can summon elementals from their respective spheres, just as druids can conjure fire or earth elementals. The summoned elemental is 60% likely to have 12 Hit Dice, 35% likely to have 16 Hit Dice, and 5% likely to have 21 to 24 Hit Dice (20+1d4). Unlike the wizard version of this spell, the caster does not need to concentrate to maintain control of the elemental since the creature regards the caster as a friend and obeys him implicitly. The elemental remains until destroyed, dispelled, sent away by a dismissal or a *holy word* spell, or the spell duration expires.

[[Player's Option- Spells and Magic/Table of ContentsTable of Contents]]
