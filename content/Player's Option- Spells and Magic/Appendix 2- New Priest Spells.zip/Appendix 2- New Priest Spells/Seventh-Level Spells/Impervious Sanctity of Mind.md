---
title: "Impervious Sanctity of Mind-- 7th Level Priest Spell (Spells and Magic)"
source: https://regalgoblins.com/2erules/SM/DD03715.htm
type:
  - Spell
level: 7
school:
  - Abjuration
---

Impervious Sanctity of Mind



(Abjuration)

    
 ---  --- 
 Sphere: Protection, Thought   
 Range: 0  Components: V, S, M 
 Duration: 1 turn/level  Casting Time: 1 round 
 Area of Effect: The caster  Saving Throw: 

None 
 

Subtlety: +6  Knockdown: 

None 
 

Sensory: 

None  Critical: 

None 



When using this spell, the priest renders his mind completely immune to any mind-affecting spell, power, or psionic effect. This includes *amnesia, awe, beguiling, charm, command, confusion, domination, emotion, empathy, ESP, fascination, fear, feeblemind, hold, hypnotism, insanity, magic jar, mind blast, phantasmal killer, possession, rulership, sleep, soul trapping, suggestion, telepathy,* and any psionic attack or power of the telepathic discipline. In short, if the spell or effect coerces the priest into taking an action or forming an impression that he doesn’t wish to, it fails while *impervious sanctity* of mind is in effect. The only mind-affecting spells or powers that can affect the protected priest are those of exceedingly powerful creatures or artifacts and relics.

Unlike the wizard spell *mind blank*, the *impervious sanctity* of mind offers no protection against detection or scrying. However, it is effective against some attacks and powers that *mind blank* is powerless against. The spell requires a small ring of lead that was once breathed upon by a red dragon.

[[Player's Option- Spells and Magic/Table of ContentsTable of Contents]]
